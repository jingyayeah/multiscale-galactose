import tellurium as te
import matplotlib.pyplot as plt

# Example that shows how to emulate a sawtooth wave

r = te.loada ('''
    center = 5;
    amplitude = 3;
    period = 1;
    
    Xo := center+amplitude*(time/period-floor(time/period+0.5))
  	 $Xo 	-> S;   Xo;
    	 S 	-> $w;  k1*S;       

     # initialize
     k1 = 1;  
     S = 1.5; 
''')

#r.conservedMoietyAnalysis = True
m1 = r.simulate (0, 10, 800, ['time', 'Xo'])

plt.ylim ((0,10))
r.plot (m1)
