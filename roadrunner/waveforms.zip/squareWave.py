
import tellurium as te
import matplotlib.pyplot as plt

# Example that shows how to emulate a square wave

r = te.loada ('''
    center = 3;
    amplitude = 4;
    period = 2;
    
    Xo := center + amplitude*piecewise(1, sin((2*pi*time)/period) > 0, 0);
  	 $Xo 	-> S;   Xo;
    	 S 	-> $w;  k1*S;       

     # initialize
     k1 = 1;  
     S = 1.5; 
''')

#r.conservedMoietyAnalysis = True
m1 = r.simulate (0, 10, 800, ['time', 'Xo'])

plt.ylim ((0,8))
r.plot (m1)




