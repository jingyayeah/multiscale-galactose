from django.contrib import admin
from polls.models import Poll

admin.site.register(Poll)
# Register your models here.
